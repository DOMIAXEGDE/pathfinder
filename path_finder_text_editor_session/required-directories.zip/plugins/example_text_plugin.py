"""Example Pathfinder text session plugin."""

def style(style_config):
    return {"accent": "#7B61FF"}

def handle(editor):
    editor["config"].setdefault("behaviors", {})["example_plugin_seen"] = True
    return {"example_plugin": "ok"}
