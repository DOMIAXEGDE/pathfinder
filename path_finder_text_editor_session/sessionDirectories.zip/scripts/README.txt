Pathfinder text editor session scripts

These files are the editable Python source for the state programs installed in
pathfinder.manifest.json. Re-run ../text-session-instruct.py through Pathfinder
after editing script paths or reinstalling the session.

State to script map:

I1  input    input/singular_create.py
I2  output   output/singular_read.py
I3  process  process/singular_update.py
I4  process  process/singular_delete.py
I5  input    input/batch_create.py
I6  output   output/batch_read.py
I7  process  process/batch_update.py
I8  process  process/batch_delete.py
I9  process  process/python_plugins.py
I10 process  process/config_style.py
I11 output   output/session_persistence.py

Interactive use:

Open the Pathfinder GUI, right-click a state, then run the input, processing,
or output behavior. When no useful payload is present, the scripts prompt for
the missing values.

Programmatic use from a Pathfinder instruction script:

result = api.run("input", "I1", {
    "id": "note-1",
    "title": "Note 1",
    "content": "Hello",
    "replace": True,
})

result = api.run("process", "I3", {
    "id": "note-1",
    "append": " world",
})

result = api.run("output", "I2", {"id": "note-1"})

The process scripts also accept transform_code for user-authored Python text
transforms. The code receives content, document, payload, config, store, and
result; either set result or define transform(content, document, payload).

Plugins:

Drop .py files into ../plugins. A plugin may define configure(config),
style(style_config), or handle(editor). The editor object exposes the store,
config, payload, documents, runtime, project paths, and CRUD helper methods.
