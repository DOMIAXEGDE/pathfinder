from pathlib import Path
import sys

_source = Path(hook.get("source_path") or ".").resolve()
_scripts_dir = _source.parent.parent
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))

from text_session_runtime import TextSessionRuntime


runtime = TextSessionRuntime(globals())
emit(runtime.persistence_summary())
