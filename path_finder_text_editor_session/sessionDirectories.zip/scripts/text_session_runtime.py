from __future__ import annotations

import datetime as _dt
import glob
import json
import os
import re
import sys
import uuid
from pathlib import Path
from typing import Any, Callable


DEFAULT_STORE = {
    "type": "pathfinder-text-session-store-v1",
    "documents": {},
    "history": [],
}


DEFAULT_CONFIG = {
    "type": "pathfinder-text-session-config-v1",
    "style": {
        "font_family": "Consolas",
        "font_size": 13,
        "foreground": "#101828",
        "background": "#FFFFFF",
        "accent": "#35B7A6",
        "line_numbers": True,
        "wrap": "word",
    },
    "behaviors": {
        "autosave": True,
        "archive_on_delete": True,
        "plugin_autoload": True,
        "default_extension": ".txt",
        "batch_export_format": "json",
    },
    "plugins": {
        "directory": "plugins",
        "enabled": True,
    },
}


def _deepcopy_json(value: Any) -> Any:
    return json.loads(json.dumps(value))


def _now_utc() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def _atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        tmp.replace(path)
    finally:
        if tmp.exists():
            tmp.unlink()


def _read_json(path: Path, default: Any) -> Any:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return _deepcopy_json(default)


def _slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "-", value.strip()).strip("-")
    return value or "document"


def _coerce_document(item: Any, fallback_id: str) -> dict[str, Any]:
    if isinstance(item, dict):
        doc = dict(item)
    else:
        doc = {"content": "" if item is None else str(item)}
    doc_id = str(doc.get("id") or doc.get("name") or fallback_id)
    doc["id"] = doc_id
    doc.setdefault("title", doc_id)
    doc.setdefault("content", "")
    doc.setdefault("metadata", {})
    doc.setdefault("revisions", [])
    return doc


class TextSessionRuntime:
    def __init__(self, pf_globals: dict[str, Any]):
        self.g = pf_globals
        self.manifest = pf_globals["manifest"]
        self.manifest_path = Path(pf_globals.get("manifest_path") or ".").resolve()
        self.session = pf_globals.get("session")
        self.session_path = Path(pf_globals["session_path"]).resolve() if pf_globals.get("session_path") else None
        self.state_id = str(pf_globals.get("state_id") or "")
        self.state = pf_globals.get("state") or {}
        self.cursor = pf_globals.get("cursor") or {}
        self.event = pf_globals.get("event") or {}
        self.hook = pf_globals.get("hook") or {}
        self.emit_fn: Callable[[Any], Any] = pf_globals.get("emit") or (lambda value=None: value)
        self.now_utc: Callable[[], str] = pf_globals.get("now_utc") or _now_utc

        text_cfg = self.manifest.setdefault("text_editor_session", {})
        self.project_dir = Path(self.manifest.get("output_directory") or self.manifest_path.parent).resolve()
        self.store_path = Path(text_cfg.get("store_path") or self.project_dir / "text-session-store.json").resolve()
        self.config_path = Path(text_cfg.get("config_path") or self.project_dir / "text-session-config.json").resolve()
        self.plugins_dir = Path(text_cfg.get("plugins_dir") or self.project_dir / "plugins").resolve()
        self.exports_dir = Path(text_cfg.get("exports_dir") or self.project_dir / "exports").resolve()
        self.scripts_dir = Path(text_cfg.get("scripts_dir") or self._infer_scripts_dir()).resolve()

        payload = self.event.get("payload", {}) if isinstance(self.event, dict) else {}
        self.payload = payload if isinstance(payload, dict) else {"value": payload}

        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        self.scripts_dir.mkdir(parents=True, exist_ok=True)

        default_config = _deepcopy_json(DEFAULT_CONFIG)
        default_config["plugins"]["directory"] = str(self.plugins_dir)
        self.store = _read_json(self.store_path, DEFAULT_STORE)
        self.config = _read_json(self.config_path, default_config)
        self.config.setdefault("plugins", {})["directory"] = str(self.plugins_dir)

    def _infer_scripts_dir(self) -> Path:
        source_path = self.hook.get("source_path")
        if source_path:
            path = Path(source_path).resolve()
            if path.parent.name in {"input", "process", "output"}:
                return path.parent.parent
            return path.parent
        return self.project_dir / "scripts"

    def emit(self, value: Any) -> Any:
        return self.emit_fn(value)

    def save(self) -> None:
        text_cfg = self.manifest.setdefault("text_editor_session", {})
        text_cfg.update(
            {
                "store_path": str(self.store_path),
                "config_path": str(self.config_path),
                "plugins_dir": str(self.plugins_dir),
                "exports_dir": str(self.exports_dir),
                "scripts_dir": str(self.scripts_dir),
            }
        )
        _atomic_write_json(self.store_path, self.store)
        _atomic_write_json(self.config_path, self.config)

    def documents(self) -> dict[str, Any]:
        return self.store.setdefault("documents", {})

    def record(self, action: str, detail: dict[str, Any]) -> None:
        self.store.setdefault("history", []).append(
            {
                "at": self.now_utc(),
                "state": self.state_id,
                "action": action,
                "detail": detail,
            }
        )

    def active_document_id(self) -> str | None:
        doc_id = self.payload.get("id") or self.payload.get("document_id")
        if doc_id:
            return str(doc_id)
        doc_id = self.store.get("active_document_id")
        if doc_id:
            return str(doc_id)
        if isinstance(self.session, dict):
            session_editor = self.session.setdefault("text_editor_session", {})
            doc_id = session_editor.get("active_document_id")
            if doc_id:
                return str(doc_id)
        docs = self.documents()
        if len(docs) == 1:
            return next(iter(docs.keys()))
        return None

    def set_active_document(self, doc_id: str | None) -> None:
        if doc_id:
            self.store["active_document_id"] = str(doc_id)
            if isinstance(self.session, dict):
                self.session.setdefault("text_editor_session", {})["active_document_id"] = str(doc_id)

    def selected_ids(self, *, include_active: bool = False, default_all: bool = False) -> list[str]:
        docs = self.documents()
        ids = self.payload.get("ids")
        if isinstance(ids, str):
            if ids.strip() in {"*", "all"}:
                return list(docs.keys())
            return [item.strip() for item in ids.split(",") if item.strip() in docs]
        if isinstance(ids, (list, tuple, set)):
            return [str(item) for item in ids if str(item) in docs]

        query = str(self.payload.get("query", "")).lower()
        if query:
            return [
                doc_id
                for doc_id, doc in docs.items()
                if query in doc_id.lower()
                or query in str(doc.get("title", "")).lower()
                or query in str(doc.get("content", "")).lower()
            ]

        if self.payload.get("all") or default_all:
            return list(docs.keys())

        doc_id = self.active_document_id() if include_active else self.payload.get("id")
        if doc_id and str(doc_id) in docs:
            return [str(doc_id)]
        return []

    def should_prompt(self, business_keys: set[str] | None = None) -> bool:
        if self.payload.get("interactive") is False:
            return False
        source = self.payload.get("source")
        if source in {"gui", "cli", "shell"}:
            if not business_keys:
                return True
            return not any(key in self.payload for key in business_keys)
        return bool(self.payload.get("interactive"))

    def ask_text(self, title: str, prompt: str, default: str = "") -> str:
        source = self.payload.get("source")
        if source == "gui":
            try:
                import tkinter as tk
                from tkinter import simpledialog

                root = tk.Tk()
                root.withdraw()
                answer = simpledialog.askstring(title, prompt, initialvalue=default, parent=root)
                root.destroy()
                return default if answer is None else answer
            except Exception:
                pass
        if sys.stdin and sys.stdin.isatty():
            raw = input(f"{prompt} [{default}]: ").strip()
            return raw or default
        return default

    def ask_yes_no(self, title: str, prompt: str, default: bool = True) -> bool:
        source = self.payload.get("source")
        if source == "gui":
            try:
                import tkinter as tk
                from tkinter import messagebox

                root = tk.Tk()
                root.withdraw()
                answer = messagebox.askyesno(title, prompt, default="yes" if default else "no", parent=root)
                root.destroy()
                return bool(answer)
            except Exception:
                pass
        if sys.stdin and sys.stdin.isatty():
            suffix = "Y/n" if default else "y/N"
            raw = input(f"{prompt} [{suffix}]: ").strip().lower()
            if not raw:
                return default
            return raw.startswith("y")
        return default

    def _content_from_payload(self, default: str = "") -> str:
        if "content" in self.payload:
            return str(self.payload["content"])
        path = self.payload.get("path") or self.payload.get("file")
        if path:
            return Path(path).read_text(encoding=self.payload.get("encoding", "utf-8"))
        value = self.payload.get("value")
        if value is not None:
            return str(value)
        return default

    def create_document(self) -> dict[str, Any]:
        docs = self.documents()
        interactive = self.should_prompt({"id", "name", "title", "content", "path", "file"})
        title = str(self.payload.get("title") or "")
        if interactive and not title:
            title = self.ask_text("Create document", "Title", "Untitled document")
        doc_id = str(self.payload.get("id") or self.payload.get("name") or _slug(title) or f"doc-{len(docs) + 1:04d}")
        if interactive:
            doc_id = self.ask_text("Create document", "Document id", doc_id)
        content = self._content_from_payload("")
        if interactive and "content" not in self.payload and "path" not in self.payload and "file" not in self.payload:
            content = self.ask_text("Create document", "Content", content)

        replace = bool(self.payload.get("replace"))
        if doc_id in docs and not replace:
            if not interactive or not self.ask_yes_no("Replace document", f"Replace existing document {doc_id}?", False):
                raise ValueError(f"document already exists: {doc_id}")
            replace = True

        doc = {
            "id": doc_id,
            "title": title or str(self.payload.get("title") or doc_id),
            "content": content,
            "metadata": dict(self.payload.get("metadata") or {}),
            "created_at": docs.get(doc_id, {}).get("created_at") if replace else self.now_utc(),
            "updated_at": self.now_utc(),
            "revisions": list(docs.get(doc_id, {}).get("revisions", [])) if replace else [],
        }
        if replace and doc_id in docs:
            doc["revisions"].append({"at": self.now_utc(), "content": docs[doc_id].get("content", "")})
        docs[doc_id] = doc
        self.set_active_document(doc_id)
        self.record("create" if not replace else "replace", {"id": doc_id})
        self.save()
        return {"created": doc_id, "replaced": replace, "document": doc, "count": len(docs)}

    def read_document(self) -> dict[str, Any]:
        docs = self.documents()
        ids = self.selected_ids(include_active=True)
        if self.should_prompt({"id", "ids", "query", "all"}):
            default_id = ids[0] if ids else self.active_document_id() or ""
            requested = self.ask_text("Read document", "Document id, query, or all", default_id or "all")
            if requested.lower() == "all":
                ids = list(docs.keys())
            elif requested in docs:
                ids = [requested]
            else:
                self.payload["query"] = requested
                ids = self.selected_ids()
        if not ids and not self.payload.get("id"):
            ids = list(docs.keys())
        selected = [docs[doc_id] for doc_id in ids if doc_id in docs]
        for doc_id in ids:
            if doc_id in docs:
                self.record("read", {"id": doc_id})
                self.set_active_document(doc_id)
        self.save()
        return {"documents": selected, "count": len(selected)}

    def _apply_content_edits(self, doc: dict[str, Any]) -> str:
        content = str(doc.get("content", ""))
        if "content" in self.payload or "path" in self.payload or "file" in self.payload or "value" in self.payload:
            content = self._content_from_payload(content)
        if "prepend" in self.payload:
            content = str(self.payload["prepend"]) + content
        if "prefix" in self.payload:
            content = str(self.payload["prefix"]) + content
        if "append" in self.payload:
            content += str(self.payload["append"])
        if "suffix" in self.payload:
            content += str(self.payload["suffix"])
        if "find" in self.payload:
            content = content.replace(str(self.payload.get("find", "")), str(self.payload.get("replace", "")))

        transform = self.payload.get("transform")
        if transform == "upper":
            content = content.upper()
        elif transform == "lower":
            content = content.lower()
        elif transform == "title":
            content = content.title()
        elif transform == "strip":
            content = content.strip()

        transform_code = self.payload.get("transform_code")
        if transform_code:
            ns = {
                "content": content,
                "document": doc,
                "payload": self.payload,
                "config": self.config,
                "store": self.store,
                "result": content,
            }
            exec(str(transform_code), ns, ns)
            if callable(ns.get("transform")):
                content = str(ns["transform"](content, doc, self.payload))
            else:
                content = str(ns.get("result", content))
        return content

    def update_document(self) -> dict[str, Any]:
        docs = self.documents()
        doc_id = self.active_document_id()
        if self.should_prompt({"id", "content", "append", "prepend", "find", "replace", "path", "file", "transform"}):
            doc_id = self.ask_text("Update document", "Document id", doc_id or "")
            mode = self.ask_text("Update document", "Mode: replace, append, prepend, find, upper, lower, title, strip", "append")
            if mode in {"upper", "lower", "title", "strip"}:
                self.payload["transform"] = mode
            elif mode == "find":
                self.payload["find"] = self.ask_text("Find", "Find text", "")
                self.payload["replace"] = self.ask_text("Replace", "Replace with", "")
            else:
                self.payload[mode if mode in {"append", "prepend"} else "content"] = self.ask_text("Update document", "Text", "")
        if not doc_id or doc_id not in docs:
            raise KeyError(f"document not found: {doc_id}")
        doc = docs[doc_id]
        doc.setdefault("revisions", []).append({"at": self.now_utc(), "content": doc.get("content", "")})
        content = self._apply_content_edits(doc)
        doc["content"] = content
        if "title" in self.payload:
            doc["title"] = str(self.payload["title"])
        doc["metadata"] = {**dict(doc.get("metadata") or {}), **dict(self.payload.get("metadata") or {})}
        doc["updated_at"] = self.now_utc()
        self.set_active_document(doc_id)
        self.record("update", {"id": doc_id})
        self.save()
        return {"updated": doc_id, "length": len(content), "document": doc}

    def delete_document(self) -> dict[str, Any]:
        docs = self.documents()
        doc_id = self.active_document_id()
        if self.should_prompt({"id"}):
            doc_id = self.ask_text("Delete document", "Document id", doc_id or "")
            if not self.ask_yes_no("Delete document", f"Delete {doc_id}?", False):
                return {"deleted": None, "cancelled": True, "remaining": len(docs)}
        if not doc_id or doc_id not in docs:
            raise KeyError(f"document not found: {doc_id}")
        deleted = docs.pop(doc_id)
        if self.config.get("behaviors", {}).get("archive_on_delete", True) or self.payload.get("archive"):
            self.store.setdefault("deleted_archive", []).append({"at": self.now_utc(), "document": deleted})
        if self.store.get("active_document_id") == doc_id:
            self.store.pop("active_document_id", None)
        self.record("delete", {"id": doc_id})
        self.save()
        return {"deleted": doc_id, "remaining": len(docs)}

    def _documents_from_paths(self) -> list[dict[str, Any]]:
        paths: list[str] = []
        for key in ("path", "file"):
            if self.payload.get(key):
                paths.append(str(self.payload[key]))
        value = self.payload.get("paths") or self.payload.get("files") or []
        if isinstance(value, str):
            paths.extend([item.strip() for item in value.split(",") if item.strip()])
        elif isinstance(value, (list, tuple, set)):
            paths.extend(str(item) for item in value)
        directory = self.payload.get("directory")
        if directory:
            pattern = str(Path(directory) / str(self.payload.get("glob", "*.txt")))
            paths.extend(glob.glob(pattern))
        docs = []
        for path_text in paths:
            path = Path(path_text)
            if path.is_file():
                docs.append(
                    {
                        "id": self.payload.get("id_prefix", "") + _slug(path.stem),
                        "title": path.name,
                        "content": path.read_text(encoding=self.payload.get("encoding", "utf-8")),
                        "metadata": {"source_path": str(path.resolve())},
                    }
                )
        return docs

    def batch_create(self) -> dict[str, Any]:
        docs = self.documents()
        incoming = self.payload.get("documents")
        if incoming is None:
            incoming = self._documents_from_paths()
        if isinstance(incoming, dict):
            incoming = [incoming]
        if not incoming and self.should_prompt({"documents", "paths", "files", "directory"}):
            count_text = self.ask_text("Batch create", "Number of starter documents", "2")
            prefix = self.ask_text("Batch create", "Document id prefix", "batch")
            try:
                count = max(1, int(count_text))
            except ValueError:
                count = 2
            incoming = [
                {"id": f"{prefix}-{index:04d}", "title": f"{prefix} document {index}", "content": ""}
                for index in range(1, count + 1)
            ]
        if not incoming:
            incoming = [
                {"id": "batch-0001", "title": "Batch document 1", "content": "Generated by batch create."},
                {"id": "batch-0002", "title": "Batch document 2", "content": "Generated by batch create."},
            ]
        created = []
        for index, item in enumerate(incoming, 1):
            doc = _coerce_document(item, f"doc-{len(docs) + index:04d}")
            existing = docs.get(doc["id"])
            doc["created_at"] = existing.get("created_at") if existing else self.now_utc()
            doc["updated_at"] = self.now_utc()
            docs[doc["id"]] = doc
            created.append(doc["id"])
        if created:
            self.set_active_document(created[-1])
        self.record("batch-create", {"ids": created})
        self.save()
        return {"created": created, "count": len(created)}

    def batch_read(self) -> dict[str, Any]:
        docs = self.documents()
        ids = self.selected_ids(default_all=True)
        if self.should_prompt({"ids", "query", "all"}):
            requested = self.ask_text("Batch read", "Ids, query, or all", "all")
            if requested.lower() == "all":
                ids = list(docs.keys())
            else:
                self.payload["ids"] = requested
                ids = self.selected_ids()
                if not ids:
                    self.payload.pop("ids", None)
                    self.payload["query"] = requested
                    ids = self.selected_ids()
        selected = [docs[doc_id] for doc_id in ids if doc_id in docs]
        export_path = None
        export = self.payload.get("export", True)
        if export:
            export_name = str(self.payload.get("export_name") or "batch-read.json")
            export_path = self.exports_dir / export_name
            export_path.parent.mkdir(parents=True, exist_ok=True)
            export_path.write_text(json.dumps(selected, indent=2, ensure_ascii=False), encoding="utf-8")
        self.record("batch-read", {"ids": ids, "export_path": str(export_path) if export_path else None})
        self.save()
        return {"documents": selected, "count": len(selected), "export_path": str(export_path) if export_path else None}

    def batch_update(self) -> dict[str, Any]:
        docs = self.documents()
        ids = self.selected_ids(default_all=bool(self.payload.get("all", True)))
        if self.should_prompt({"ids", "query", "all", "content", "append", "prepend", "find", "replace", "transform"}):
            requested = self.ask_text("Batch update", "Ids, query, or all", "all")
            if requested.lower() == "all":
                ids = list(docs.keys())
            else:
                self.payload["query"] = requested
                ids = self.selected_ids()
            mode = self.ask_text("Batch update", "Mode: append, prepend, find, upper, lower, title, strip", "append")
            if mode in {"upper", "lower", "title", "strip"}:
                self.payload["transform"] = mode
            elif mode == "find":
                self.payload["find"] = self.ask_text("Find", "Find text", "")
                self.payload["replace"] = self.ask_text("Replace", "Replace with", "")
            else:
                self.payload[mode if mode in {"append", "prepend"} else "append"] = self.ask_text("Batch update", "Text", "")
        updated = []
        for doc_id in ids:
            doc = docs.get(doc_id)
            if not doc:
                continue
            doc.setdefault("revisions", []).append({"at": self.now_utc(), "content": doc.get("content", "")})
            doc["content"] = self._apply_content_edits(doc)
            doc["updated_at"] = self.now_utc()
            updated.append(doc_id)
        self.record("batch-update", {"ids": updated})
        self.save()
        return {"updated": updated, "count": len(updated)}

    def batch_delete(self) -> dict[str, Any]:
        docs = self.documents()
        ids = self.selected_ids(default_all=False)
        if self.should_prompt({"ids", "query", "all"}):
            requested = self.ask_text("Batch delete", "Ids, query, or all", "")
            if requested.lower() == "all":
                ids = list(docs.keys())
            else:
                self.payload["query"] = requested
                ids = self.selected_ids()
            if not self.ask_yes_no("Batch delete", f"Delete {len(ids)} documents?", False):
                return {"deleted": [], "cancelled": True, "remaining": len(docs)}
        deleted = []
        archive = self.store.setdefault("deleted_archive", [])
        for doc_id in ids:
            if doc_id not in docs:
                continue
            doc = docs.pop(doc_id)
            deleted.append(doc_id)
            if self.config.get("behaviors", {}).get("archive_on_delete", True) or self.payload.get("archive", True):
                archive.append({"at": self.now_utc(), "document": doc})
        self.record("batch-delete", {"ids": deleted})
        self.save()
        return {"deleted": deleted, "count": len(deleted), "remaining": len(docs)}

    def run_plugins(self) -> dict[str, Any]:
        if self.config.get("plugins", {}).get("enabled", True) is False:
            return {"plugins": [], "count": 0, "skipped": "plugins disabled"}
        requested = self.payload.get("plugins")
        if isinstance(requested, str):
            requested_names = {item.strip() for item in requested.split(",") if item.strip()}
        elif isinstance(requested, (list, tuple, set)):
            requested_names = {str(item) for item in requested}
        else:
            requested_names = set()
        results = []
        editor = {
            "runtime": self,
            "manifest": self.manifest,
            "store": self.store,
            "config": self.config,
            "documents": self.documents(),
            "payload": self.payload,
            "event": self.event,
            "cursor": self.cursor,
            "project_dir": self.project_dir,
            "plugins_dir": self.plugins_dir,
            "exports_dir": self.exports_dir,
            "create_document": self.create_document,
            "read_document": self.read_document,
            "update_document": self.update_document,
            "delete_document": self.delete_document,
            "emit": self.emit,
        }
        for plugin_path in sorted(self.plugins_dir.glob("*.py")):
            if requested_names and plugin_path.name not in requested_names and plugin_path.stem not in requested_names:
                continue
            ns = {
                "manifest": self.manifest,
                "store": self.store,
                "config": self.config,
                "payload": self.payload,
                "event": self.event,
                "cursor": self.cursor,
                "project_dir": self.project_dir,
                "Path": Path,
                "json": json,
                "now_utc": self.now_utc,
                "emit": self.emit,
                "editor": editor,
            }
            exec(compile(plugin_path.read_text(encoding="utf-8"), str(plugin_path), "exec"), ns, ns)
            result = None
            if callable(ns.get("configure")):
                result = ns["configure"](self.config)
            if callable(ns.get("style")):
                style_result = ns["style"](self.config.setdefault("style", {}))
                if isinstance(style_result, dict):
                    self.config.setdefault("style", {}).update(style_result)
                    result = style_result
            if callable(ns.get("handle")):
                result = ns["handle"](editor)
            results.append({"plugin": plugin_path.name, "result": result})
        self.record("plugins", {"plugins": [item["plugin"] for item in results]})
        self.save()
        return {"plugins": results, "count": len(results)}

    def configure(self) -> dict[str, Any]:
        if self.payload.get("reset"):
            plugins = self.config.get("plugins", {})
            self.config = _deepcopy_json(DEFAULT_CONFIG)
            self.config["plugins"] = {**self.config.get("plugins", {}), **plugins, "directory": str(self.plugins_dir)}
        if self.should_prompt({"style", "behaviors", "reset"}):
            size = self.ask_text("Text session style", "Font size", str(self.config.get("style", {}).get("font_size", 13)))
            accent = self.ask_text("Text session style", "Accent color", str(self.config.get("style", {}).get("accent", "#35B7A6")))
            try:
                self.config.setdefault("style", {})["font_size"] = int(size)
            except ValueError:
                pass
            self.config.setdefault("style", {})["accent"] = accent
        self.config.setdefault("style", {}).update(dict(self.payload.get("style") or {}))
        self.config.setdefault("behaviors", {}).update(dict(self.payload.get("behaviors") or {}))
        self.config.setdefault("plugins", {}).update(dict(self.payload.get("plugins_config") or {}))
        self.config.setdefault("plugins", {})["directory"] = str(self.plugins_dir)
        self.record("configure", {"style": self.config.get("style", {}), "behaviors": self.config.get("behaviors", {})})
        self.save()
        return self.config

    def persistence_summary(self) -> dict[str, Any]:
        summary = {
            "manifest": str(self.manifest_path),
            "session": str(self.session_path) if self.session_path else None,
            "store": str(self.store_path),
            "config": str(self.config_path),
            "plugins": str(self.plugins_dir),
            "scripts": str(self.scripts_dir),
            "exports": str(self.exports_dir),
            "document_count": len(self.documents()),
            "history_count": len(self.store.get("history", [])),
            "active_document_id": self.store.get("active_document_id"),
        }
        summary_path = self.project_dir / str(self.payload.get("summary_name", "text-session-summary.json"))
        summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self.record("persist", {"summary_path": str(summary_path)})
        self.save()
        summary["summary_path"] = str(summary_path)
        return summary
